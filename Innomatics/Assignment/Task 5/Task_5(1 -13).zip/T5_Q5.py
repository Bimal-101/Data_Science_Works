import re

a = input()
b = input()

log = re.compile(b)
c = log.search(a)
if not c:
    print("(-1, -1)")
    
while c:
    print("({}, {})".format(c.start(),c.end()-1))
    c = log.search(a,c.start()+1)
