#Task 5 - Groups

import re

log = r"([A-Z,a-z,0-9])\1+"

a = re.search(log, input())
if a:
    print(a.group(1))
else:
    print(-1)
