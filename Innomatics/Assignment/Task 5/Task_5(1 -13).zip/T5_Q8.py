#Task 5 - Q8 : Validating E mail


import re

n = int(input())

for _ in range(n):
    name,email = input().split(' ')

    a = re.match(r'<[A-Z,a-z](\w|-|\.|_)*@[A-Za-z]+\.[A-Z,a-z]{1,3}>',email)
    if a :
        print(name,email)
    
