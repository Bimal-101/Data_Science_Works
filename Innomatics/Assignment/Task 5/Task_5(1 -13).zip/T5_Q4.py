#Task 5 - Q4 : Find all

import re

vov = "aeiou"
con = "qwrtypsdfghjklzxcvbnm"
log = r'(?<=[%s])([%s]{2,})[%s]'
a = re.findall(log % (con,vov,con), input(), flags = re.I)
if a:
    print('\n'.join(a))
else:
    print(-1)
