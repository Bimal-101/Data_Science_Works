#Task 5 - Q1 : Detecting floating point number

import re

a = []

for i in range(int(input())):
    log = r'[-+]?\d*\.\d+$'
    i = bool(re.match(log,input()))
    a.append(i)
print(*a,sep='\n')
