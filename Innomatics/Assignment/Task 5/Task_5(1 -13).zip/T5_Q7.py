#Task 5 - Q7 : Validate Phone Numbert

import re

n = int(input())

start = "^[789]"

for i in range(n):
    a = input()
    if len(a)==10 and a.isdigit():
        b = re.findall(start,a)
        if len(b)==1:
            print("YES")
        else:
            print("NO")
    else:
        print("NO")
