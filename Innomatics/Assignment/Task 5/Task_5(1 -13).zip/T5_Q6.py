#Task 5 - Q 6 : Roman Numerals

m = "M{0,3}"
c = "(C[MD]|D?C{0,3})"
x = "(X[CL]|L?X{0,3})"
i = "(I[XV]|V?I{0,3})" 

regex_pattern = r"%s%s%s%s$"%(m,c,x,i)	# Do not delete 'r'.



import re
print(str(bool(re.match(regex_pattern, input()))))
