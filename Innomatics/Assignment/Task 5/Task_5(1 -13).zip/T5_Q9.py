#Task 5 - Q9 : Hex Colour Code


import re

n = int(input())

a = [input() for _ in range(n)]

b = '\n'.join(a)

log = r'(?!^)#([0-9,a-f,A-F]{3,6})'
c = re.findall(log,b,re.MULTILINE)

for i in c:
    print(f'#{i}')
    
