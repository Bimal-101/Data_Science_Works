#Task 5 - Reg Ex Substitution

import re

def fu(a):
    if a.group(1) == '||':
        return 'or'
    else:
        return 'and' 

log = r'(?<= )(\|\||&&)(?= )'
for _ in range(int(input())):
    print(re.sub(log,fu,input()))
