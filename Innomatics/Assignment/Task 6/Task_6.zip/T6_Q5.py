#Task 6 - Q6 : Zeros and Ones

import numpy as np

inp = tuple(map(int,input().split()))

print(np.zeros(inp, dtype = int))
print(np.ones(inp, dtype = int))
