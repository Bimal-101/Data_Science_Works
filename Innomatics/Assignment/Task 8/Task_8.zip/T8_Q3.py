#Task 8 - Q3 : Normal Distributuion 1

from math import erf


def fu(x):
  z = (x - 20)/(2*2**(0.5))
  return (0.5 * (1 + erf(z)))

print(round(fu(19.5), 3))
print(round((fu(22) - fu(20)), 3))
