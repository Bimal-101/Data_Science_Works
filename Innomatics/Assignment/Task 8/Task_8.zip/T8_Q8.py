#Task 8 - Q8 : Correlation Coefficient

n = int(input())
x = list(map(float,input().split()))
y = list(map(float,input().split()))

MuX = (sum(x))/n
MuY = (sum(y))/n

x2 = []
y2 = []
for i in range(n):
    a1 = x[i] - MuX
    a2 = a1**2
    x2.append(a2)
for i in range(n):
    b1 = y[i] - MuY
    b2 = b1**2
    y2.append(b2)
    
StdX = (sum(x2)/n)**(0.5)
StdY = (sum(y2)/n)**(0.5)

z = []
for i in range(n):
    c1 = (x[i] - MuX)*( y[i] - MuY)
    z.append(c1)

cov = sum(z)/n

cor = cov/(StdX*StdY)

print(round(cor,3))

