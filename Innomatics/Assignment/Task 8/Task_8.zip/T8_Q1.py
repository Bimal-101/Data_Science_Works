#Task 8 - Q1 : Binomial Distribution 1

a, b = map(float,input().split())

p = b/(a+b)
q = 1 - p

l = q**6
m = 6*p*(q**5)
n = 15*(p**2)*(q**4)
o = 20*(p**3)*(q**3)

S = l+m+n+o



print(round(S,3))
