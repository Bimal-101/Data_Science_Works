#Task 8 - Q4 : Normal 2


from math import erf


def fu(x):
  z = (x - 70)/(10*2**(0.5))
  return (0.5 * (1 + erf(z)))

a = (1 - fu(80))*100
b = (1 - fu(60))*100
c = fu(60)*100

print(round(a,2))
print(round(b,2))
print(round(c,2))
