#Task 8 - Q9 Simple Linear Regression


n = 5
x = [95,85,80,70,60]
y = [85,95,70,65,70]

MuX = (sum(x))/n
MuY = (sum(y))/n

x2 = []

for i in range(n):
    a1 = (x[i] - MuX)
    a2 = a1**2
    x2.append(a2)


z = []
for i in range(n):
    c1 = (x[i] - MuX)*(y[i])
    z.append(c1)
    
b = sum(z)/sum(x2)

a = MuY - b*MuX

EstY = a + b*80

print(round(EstY,3))
