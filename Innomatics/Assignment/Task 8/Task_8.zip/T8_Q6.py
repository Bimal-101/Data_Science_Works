#Task 8 - Q6 : CLT2

from math import erf


def fu(a,b,c,d):
  z = (a - (b*c))/((d*b**(0.5))*(2**(0.5)))
  return (0.5 * (1 + erf(z)))
x = fu(250,100,2.4,2)
print(round(x,4))
