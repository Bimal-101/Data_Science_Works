#Task 8 - Q2 : Binomial Distribution 2

p = 12/100
q = 1 - p

p0 = q**10
p1 = 10*p*(q**9)
p2 = 45*p**2*(q**8)

tp = p0+p1+p2
s = 1 - (p0+p1)
print(round(tp,3))
print(round(s,3))
