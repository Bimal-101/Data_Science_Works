#Task 8 - Q7 : CLT 3 

mu = 500
sig = 80
std = 80/(100**(0.5))
z = 1.96

a = mu - std*z
b = mu + std*z

print(a)
print(b)
