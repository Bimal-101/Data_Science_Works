#Task 3 - Q6 : Integers come all in size

a = int(input())
b = int(input())
c = int(input())
d = int(input())

print(pow(a,b)+pow(c,d))
