#Task 3 - Q5 : Power Mod Power

a = int(input())
b = int(input())
c = int(input())

print(pow(a,b))
print(pow(a,b,c))
