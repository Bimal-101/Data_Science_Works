# Task 3 - Q3 : Triangle quest 2

for i in range(1,int(input())+1):
    print(((10**i)//9)**2)

# Another Methode - Using String
# for i in range(1,int(input())+1):
#       print(int(str(i//i)*i)**i)
