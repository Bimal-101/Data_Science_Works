#Task 3 - Q1 : Polar Form

import cmath

c = complex(input())


print(abs(c))
print(cmath.phase(c))
