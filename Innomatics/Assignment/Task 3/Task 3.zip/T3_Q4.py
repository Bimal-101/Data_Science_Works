# Task 3 - Q4 : DivMod

a = int(input())
b = int(input())

c = divmod(a,b)

print(c[0])
print(c[1])
print(c)
